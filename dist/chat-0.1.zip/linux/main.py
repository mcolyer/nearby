#!/usr/bin/env python

from twisted.internet import gtk2reactor
gtk2reactor.install()

import gtk
import pango
from SimpleGladeApp import SimpleGladeApp

from twisted.internet.protocol import ClientFactory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor

import re

class NearbyChat(SimpleGladeApp, LineReceiver):
    def __init__(self, *args):
        self.buffer = gtk.TextBuffer()
        #Highlighted username tag
        self.buffer.create_tag("user", weight=pango.WEIGHT_BOLD, foreground="blue")
	
        SimpleGladeApp.__init__(self, "chat.glade")
        self.received_text.set_buffer(self.buffer)
    
    def connectionMade(self):
        self.sendLine("REGISTER chat 0.1")

    def lineReceived(self, line):
        print "DEBUG:", line
        receiveRe = re.compile("^RECEIVE (\S+) (\S+) (.*)$")
        if not receiveRe.match(line):
            #If we are passed a garbage message fail silently
            return
        nodeid, username, message = receiveRe.match(line).groups(1)
        self.buffer.insert_with_tags_by_name(self.buffer.get_end_iter(), "%s: " % username, "user")
        self.buffer.insert_at_cursor("%s\n" % message)

    def new(self):
	    pass

    def on_file_save(self, widget, data=None):
        pass

    def on_file_open(self, widget, data=None):
        filter = gtk.FileFilter()
        filter.add_pattern("*.txt")
        self.dialog_file_open.set_filter(filter)
        self.dialog_file_open.show()

    def on_file_open_response(self, widget, response, data=None):
        self.dialog_file_open.hide()
        if (response == gtk.RESPONSE_OK):
            pass
    def on_text_entry_key_release(self, widget, event):
        if gtk.gdk.keyval_name(event.keyval) == "Return":
            print "SEND "+self.text_entry.get_text()
            self.sendLine("SEND "+self.text_entry.get_text())

    def on_quit(self, widget):
        self.transport.loseConnection()

class NearbyClientFactory(ClientFactory):
    protocol = NearbyChat

    def startedConnecting(self, connector):
        print "connecting"

    def clientConnectionFailed(self, connector, reason):
        print 'connection failed:', reason.getErrorMessage()
        reactor.stop()

    def clientConnectionLost(self, connector, reason):
        print 'connection lost:', reason.getErrorMessage()
        reactor.stop()

def main():
	factory = NearbyClientFactory()
	reactor.connectTCP('localhost', 8002, factory)
	reactor.run()

if __name__ == "__main__":
	main()

#vim: set ts=4 sw=4 expandtab :
